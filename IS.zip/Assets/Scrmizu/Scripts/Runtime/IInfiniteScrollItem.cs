// Scrmizu C# reference source
// Copyright (c) 2016-2020 COMCREATE. All rights reserved.

namespace Scrmizu
{
    public interface IInfiniteScrollItem
    {
        void UpdateItemData(object data);
        void Hide();
    }
}