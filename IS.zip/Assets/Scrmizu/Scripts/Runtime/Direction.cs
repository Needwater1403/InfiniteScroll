﻿// Scrmizu C# reference source
// Copyright (c) 2016-2020 COMCREATE. All rights reserved.

namespace Scrmizu
{
    /// <summary>
    /// Direction type
    /// </summary>
    public enum Direction
    {
        Vertical = 0,
        Horizontal = 1,
    }
}