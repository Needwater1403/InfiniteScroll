﻿// Scrmizu C# reference source
// Copyright (c) 2016-2020 COMCREATE. All rights reserved.

namespace Scrmizu.Sample
{
    public class ScrollItemData
    {
        public string title;
        public int count;
        public string value;
    }
}