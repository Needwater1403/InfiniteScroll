using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestScrollListItem : MonoBehaviour
{
    public int index;
    public bool canSwap;
}
